﻿namespace GorillaTagModTemplateProject
{
	class PluginInfo
	{
		public const string GUID = "com.TimeInVR.gorillatag.ScrewTheGame";
		public const string Name = "ScrewTheGame";
		public const string Version = "1.0.0";
	}
}
